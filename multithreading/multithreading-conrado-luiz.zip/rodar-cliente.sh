gcc -o cliente cliente.c
./cliente