gcc -pthread -o serv serv-conc.c
./serv